Μπορείτε να κάνετε compile τα αρχεία lexer.l και parser.y εκτελώντας στο terminal την εντολή:

# make